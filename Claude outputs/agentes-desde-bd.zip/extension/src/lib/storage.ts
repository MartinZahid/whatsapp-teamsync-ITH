import type { Agent, AgentStatus } from '@shared/types'

// Claves usadas en chrome.storage.local.
export const KEYS = {
  config: 'wts_config',
  agents: 'wts_agents',
  selectors: 'wts_selectors',
  presence: 'wts_presence',
  connection: 'wts_connection',
  status: 'wts_status',
  currentContact: 'wts_current_contact',
  panelCollapsed: 'wts_panel_collapsed'
} as const

export const DEFAULT_SERVER_URL = 'ws://localhost:3001'
// Encabezado de la conversación abierta en WhatsApp Web (nombre del contacto).
export const DEFAULT_SELECTOR =
  'div[data-testid="conversation-panel-wrapper"] header span[data-testid="conversation-info-header-chat-title"]'
// Selector de versiones anteriores; solo se usa para migrar lo que haya guardado.
const LEGACY_SELECTOR = '#main header span[title]'

export interface AgentConfig {
  name: string
  serverUrl: string
}

export interface ConnectionState {
  status: 'disconnected' | 'connecting' | 'connected'
  message?: string
  updatedAt: number
}

export interface Selectors {
  chatTitle: string
}

function read<T>(key: string): Promise<T | undefined> {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (result) => resolve(result[key] as T | undefined))
  })
}

function write(key: string, value: unknown): Promise<void> {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [key]: value }, () => resolve())
  })
}

export async function getConfig(): Promise<AgentConfig> {
  return (await read<AgentConfig>(KEYS.config)) ?? { name: '', serverUrl: DEFAULT_SERVER_URL }
}

export function saveConfig(config: AgentConfig): Promise<void> {
  return write(KEYS.config, config)
}

// Última lista de agentes recibida del servidor (caché para cuando no responde).
export async function getAgentsList(): Promise<string[]> {
  return (await read<string[]>(KEYS.agents)) ?? []
}

export function saveAgentsList(agents: string[]): Promise<void> {
  return write(KEYS.agents, agents)
}

export async function getSelectors(): Promise<Selectors> {
  const saved = await read<Selectors>(KEYS.selectors)
  if (!saved) return { chatTitle: DEFAULT_SELECTOR }
  // Si quedó guardado el selector viejo, usamos el nuevo sin obligar a cambiar.
  if (saved.chatTitle === LEGACY_SELECTOR) return { chatTitle: DEFAULT_SELECTOR }
  return saved
}

export function saveSelectors(selectors: Selectors): Promise<void> {
  return write(KEYS.selectors, selectors)
}

export async function getPresence(): Promise<Agent[]> {
  return (await read<Agent[]>(KEYS.presence)) ?? []
}

export function savePresence(agents: Agent[]): Promise<void> {
  return write(KEYS.presence, agents)
}

export async function getConnection(): Promise<ConnectionState> {
  return (
    (await read<ConnectionState>(KEYS.connection)) ?? { status: 'disconnected', updatedAt: Date.now() }
  )
}

export function saveConnection(connection: ConnectionState): Promise<void> {
  return write(KEYS.connection, connection)
}

export async function getSavedStatus(): Promise<AgentStatus> {
  const saved = await read<string>(KEYS.status)
  // Versiones anteriores guardaban 'active'; hoy el estado se llama 'attending'.
  if (saved === 'active') return 'attending'
  return (saved as AgentStatus | undefined) ?? 'available'
}

export function saveStatus(status: AgentStatus): Promise<void> {
  return write(KEYS.status, status)
}

export async function getCurrentContact(): Promise<string | null> {
  return (await read<string | null>(KEYS.currentContact)) ?? null
}

export function saveCurrentContact(contact: string | null): Promise<void> {
  return write(KEYS.currentContact, contact)
}

export async function getPanelCollapsed(): Promise<boolean> {
  return (await read<boolean>(KEYS.panelCollapsed)) ?? false
}

export function savePanelCollapsed(collapsed: boolean): Promise<void> {
  return write(KEYS.panelCollapsed, collapsed)
}
